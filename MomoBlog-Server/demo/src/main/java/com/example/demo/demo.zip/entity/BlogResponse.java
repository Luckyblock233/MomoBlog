package com.example.demo.entity;

import java.util.List;

public class BlogResponse {
    private List<Blog> data;
    public List<Blog> getData() {
        return data;
    }
}