package com.example.demo.values;

public class ConstMessages {
    public static final String uploadAvatarDir = "demo\\src\\main\\resources\\static\\upload\\avatars";
    public static final String uploadBlogImageDir = "demo\\src\\main\\resources\\static\\upload\\images";
}
