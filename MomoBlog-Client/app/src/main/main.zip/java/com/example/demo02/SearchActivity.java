package com.example.demo02;

import android.app.Activity;

public class SearchActivity extends Activity {
}
