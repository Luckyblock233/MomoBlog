package com.example.demo02.ui.Activity;

import androidx.appcompat.app.AppCompatActivity;

public class whatshotActivity extends AppCompatActivity {

}
